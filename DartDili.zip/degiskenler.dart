void main() {
  
  //camelCase
  //PascalCase

  String mesaj = "Merhaba Engin";
  int dogumYili = 1985;
  double oran = 1.15;
  bool loginMi = false;


	print(mesaj);
  print("Doğum yılı : "+dogumYili.toString());
  print("Oran : " + oran.toString());


}